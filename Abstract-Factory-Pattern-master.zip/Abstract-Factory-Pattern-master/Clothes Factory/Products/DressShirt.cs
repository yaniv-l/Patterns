﻿using Clothes_Factory.Abstract_products;

namespace Clothes_Factory.Products
{
    class DressShirt : Shirt 
    {
    }
}
