﻿namespace Clothes_Factory.Abstract_products
{
    abstract class Trousers
    {
    }
}
